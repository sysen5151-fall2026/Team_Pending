"""Build a transparent 1 km biodiversity-risk grid for Tompkins County.

Required raw inputs:
  data/raw/tompkins_county.geojson   (scripts/download_boundary.py)
  data/raw/gbif_occurrences.csv      (scripts/download_gbif.py)
Optional inputs:
  data/raw/protected_areas.geojson
  data/raw/roads.geojson
  data/raw/land_cover.tif            (not used yet; see KNOWN LIMITATIONS)

KNOWN LIMITATIONS (also in docs/methodology.md)
  * Urban and agriculture threat effects are set to 0 and every cell is labelled
    "Mixed habitat" until NLCD zonal statistics are implemented, so scores from
    this script are driven only by road density and protection.
  * GBIF richness is stored for context/validation and is not part of the score.
"""
import sys
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import box

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT))

from biodiversity_risk.scoring import (  # noqa: E402
    HABITAT_SENSITIVITY,
    HABITAT_SUITABILITY,
    THREAT_WEIGHTS,
    accessibility_from_protection,
    habitat_quality,
    normalize,
)

RAW = ROOT / "data/raw"
OUT = ROOT / "dist/data/risk_grid.geojson"
UTM_18N = 32618
MIN_CELL_FRACTION = 0.15  # drop sliver cells smaller than this share of a full cell

OUTPUT_FIELDS = [
    "cell_id", "habitat", "species_count", "habitat_suitability", "accessibility",
    "road_effect", "urban_effect", "agriculture_effect", "degradation",
    "habitat_quality", "risk_score", "geometry",
]


def create_grid(boundary, cell_size=1000):
    area = boundary.to_crs(UTM_18N)
    xmin, ymin, xmax, ymax = area.total_bounds
    cells = [
        box(x, y, x + cell_size, y + cell_size)
        for x in np.arange(xmin, xmax, cell_size)
        for y in np.arange(ymin, ymax, cell_size)
    ]
    grid = gpd.GeoDataFrame({"geometry": cells}, crs=area.crs)
    grid = gpd.clip(grid, area)
    grid = grid[grid.area > (cell_size * cell_size * MIN_CELL_FRACTION)].reset_index(drop=True)
    grid["cell_id"] = [f"TC-{i + 1:04d}" for i in range(len(grid))]
    return grid


def add_species_richness(grid, occurrences_csv):
    obs = pd.read_csv(occurrences_csv)
    points = gpd.GeoDataFrame(
        obs,
        geometry=gpd.points_from_xy(obs.decimalLongitude, obs.decimalLatitude),
        crs=4326,
    ).to_crs(grid.crs)
    joined = gpd.sjoin(points, grid, predicate="within")
    richness = joined.groupby("index_right")["scientificName"].nunique()
    grid["species_count"] = grid.index.to_series().map(richness).fillna(0)


def add_protection(grid, path):
    if path.exists():
        protected = gpd.read_file(path).to_crs(grid.crs)
        overlap = gpd.overlay(grid[["cell_id", "geometry"]], protected[["geometry"]], how="intersection")
        protected_area = overlap.groupby("cell_id").geometry.apply(lambda g: g.area.sum())
        grid["protected_fraction"] = (grid.cell_id.map(protected_area).fillna(0) / grid.area).clip(0, 1)
    else:
        grid["protected_fraction"] = 0
    grid["accessibility"] = accessibility_from_protection(grid["protected_fraction"])


def add_road_effect(grid, path):
    if path.exists():
        roads = gpd.read_file(path).to_crs(grid.crs)
        clipped = gpd.overlay(
            grid[["cell_id", "geometry"]], roads[["geometry"]], how="intersection", keep_geom_type=False
        )
        road_length = clipped.groupby("cell_id").geometry.apply(lambda g: g.length.sum())
        grid["road_length_m"] = grid.cell_id.map(road_length).fillna(0)
        grid["road_effect"] = normalize(grid["road_length_m"])
    else:
        grid["road_effect"] = 0


def main():
    boundary = gpd.read_file(RAW / "tompkins_county.geojson")
    grid = create_grid(boundary)
    add_species_richness(grid, RAW / "gbif_occurrences.csv")
    add_protection(grid, RAW / "protected_areas.geojson")
    add_road_effect(grid, RAW / "roads.geojson")

    # TODO: replace these neutral values with NLCD zonal statistics.
    grid["urban_effect"] = 0
    grid["agriculture_effect"] = 0
    grid["habitat"] = "Mixed habitat"

    grid["habitat_suitability"] = grid.habitat.map(HABITAT_SUITABILITY)
    grid["degradation"] = 0.0
    for threat, weight in THREAT_WEIGHTS.items():
        sensitivity = grid.habitat.map(lambda h, t=threat: HABITAT_SENSITIVITY[h][t])
        grid["degradation"] += weight * grid[f"{threat}_effect"] * sensitivity
    grid["degradation"] *= grid["accessibility"]

    grid["habitat_quality"] = habitat_quality(grid["habitat_suitability"], grid["degradation"])
    grid["risk_score"] = (1 - grid["habitat_quality"]).clip(0, 1).round(3)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    grid.to_crs(4326)[OUTPUT_FIELDS].to_file(OUT, driver="GeoJSON")
    print(f"Saved {len(grid):,} scored cells to {OUT}")


if __name__ == "__main__":
    main()
