"""Create deterministic demonstration cells so the web app works immediately.

Writes dist/data/risk_grid.geojson. The data are synthetic: they exercise the
InVEST equations and the interface, and say nothing about real habitats.
"""
import json
import math
import random
import sys
from pathlib import Path

ROOT = Path(__file__).parents[1]
sys.path.insert(0, str(ROOT))

from biodiversity_risk.scoring import (  # noqa: E402
    HABITAT_SUITABILITY,
    degradation,
    habitat_quality,
)

OUT = ROOT / "dist/data/risk_grid.geojson"
SEED = 5151
HABITATS = ["Forest", "Wetland", "Agriculture", "Mixed habitat"]
LAT0, LON0 = 42.28, -76.70
DY, DX = 0.055, 0.075


def clamp01(value):
    return min(1, max(0, value))


def build_features():
    random.seed(SEED)
    features = []
    for row in range(6):
        for col in range(6):
            lat = LAT0 + row * DY
            lon = LON0 + col * DX
            species = clamp01(0.35 + 0.35 * math.sin((row + 1) * 0.8) + random.uniform(-0.12, 0.12))
            habitat = HABITATS[(row + 2 * col) % len(HABITATS)]
            road = clamp01(0.12 + (5 - row) * 0.09 + random.uniform(-0.1, 0.1))
            urban = clamp01(0.08 + col * 0.11 + random.uniform(-0.1, 0.1))
            agriculture = clamp01(0.10 + abs(2.5 - row) * 0.08 + random.uniform(-0.08, 0.08))
            access = 0.3 if (row + col) % 5 == 0 else (0.65 if (row + col) % 3 == 0 else 1.0)

            effects = {"road": road, "urban": urban, "agriculture": agriculture}
            deg = degradation(effects, habitat, access)
            suitability = HABITAT_SUITABILITY[habitat]
            quality = habitat_quality(suitability, deg)
            score = round(1 - quality, 3)

            ring = [
                [lon, lat],
                [lon + DX * 0.9, lat],
                [lon + DX * 0.9, lat + DY * 0.86],
                [lon, lat + DY * 0.86],
                [lon, lat],
            ]
            features.append(
                {
                    "type": "Feature",
                    "properties": {
                        "cell_id": f"TC-{row * 6 + col + 1:04d}",
                        "habitat": habitat,
                        "species_count": round(8 + species * 55),
                        "habitat_suitability": suitability,
                        "accessibility": access,
                        "road_effect": round(road, 3),
                        "urban_effect": round(urban, 3),
                        "agriculture_effect": round(agriculture, 3),
                        "degradation": round(deg, 3),
                        "habitat_quality": round(quality, 3),
                        "risk_score": score,
                    },
                    "geometry": {"type": "Polygon", "coordinates": [ring]},
                }
            )
    return features


def main():
    features = build_features()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    collection = {"type": "FeatureCollection", "features": features}
    OUT.write_text(json.dumps(collection, separators=(",", ":")))
    print(f"Saved {len(features)} demo cells to {OUT}")


if __name__ == "__main__":
    main()
