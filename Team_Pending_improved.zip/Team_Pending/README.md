# Biodiversity Risk Map

[![CI](https://github.com/sysen5151-fall2026/Team_Pending/actions/workflows/ci.yml/badge.svg)](https://github.com/sysen5151-fall2026/Team_Pending/actions/workflows/ci.yml)

A SYSEN 5151 MVP for screening biodiversity risk across **Tompkins County, New York**. It is a browser-based decision dashboard built on the Natural Capital Project's **InVEST Habitat Quality** model, with scripts for pulling public data and demonstration data so the interface works immediately.

> **Prototype.** The bundled map uses synthetic demo cells, and all model parameters are uncalibrated. Scores are for screening and prioritization only, not a prediction of species loss and not a substitute for field assessment. See [Known limitations](#known-limitations).

**Live demo:** https://sysen5151-fall2026.github.io/Team_Pending/ (available once GitHub Pages is enabled; see [Deployment](#deployment)).

## What it does

- Shows scored grid cells on an interactive Leaflet map
- Filters cells by risk level and dominant habitat
- Breaks down each score into its component indicators
- Adjusts the priority threshold and exports priority cells to CSV
- Explains the method and appropriate use in an in-app dialog

## Quick start

Run the dashboard with the included demo data (no installs needed beyond Python 3):

```bash
cd dist
python3 -m http.server 8000
```

Open <http://localhost:8000>. A local server is required because browsers block `fetch()` calls from `file://` pages. `make serve` does the same.

## Run the tests

```bash
pip install -r requirements-dev.txt
python -m pytest        # or: make test
```

The tests cover the scoring equations and check that the demo GeoJSON is valid, internally consistent, and reproducible from `scripts/make_demo_data.py`. They run automatically on every push through GitHub Actions.

## Build a map from public data

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python scripts/download_boundary.py   # Census county boundary
python scripts/download_gbif.py       # up to 5,000 GBIF occurrences
python scripts/build_risk_grid.py     # writes dist/data/risk_grid.geojson
```

Optional layers go in `data/raw/`: `protected_areas.geojson`, `roads.geojson`, and `land_cover.tif`. Refresh the browser and the app loads the new file; no JavaScript change is needed. To restore the demo data, run `python scripts/make_demo_data.py` (or `make demo`).

> `build_risk_grid.py` overwrites `dist/data/risk_grid.geojson`, which is the committed demo file. Commit real-data output only deliberately.

## Repository layout

```text
biodiversity_risk/
  scoring.py            InVEST equations and all model parameters (single source of truth)
dist/                   deployable web app (index.html, app.js, styles.css, data/risk_grid.geojson)
scripts/
  download_boundary.py  Census TIGER county boundary
  download_gbif.py      GBIF occurrence download
  build_risk_grid.py    builds the scored GeoJSON from real data
  make_demo_data.py     regenerates the synthetic demo cells
tests/                  scoring and demo-data tests
docs/
  product-description.md
  business-mission-analysis.md
  methodology.md
  data-sources.md
data/raw, data/processed   git-ignored working data
.github/workflows/      CI tests and GitHub Pages deployment
```

## Method in brief

```text
Q    = H × [1 − D^z / (D^z + k^z)]
Risk = 1 − Q
```

`z = 2.5` is fixed by InVEST; `k = 0.5` is a documented prototype value. Threat weights, sensitivities, and `k` still need literature or expert calibration. Details and sources are in [docs/methodology.md](docs/methodology.md).

## Known limitations

- The real-data pipeline does not yet use land cover: urban and agriculture effects are set to 0 and all cells are labelled "Mixed habitat", so real-data scores vary only with road density and protection.
- Risk is dominated by habitat suitability because degradation is small relative to `k`.
- GBIF richness is displayed but not scored.

The full list is in [docs/methodology.md](docs/methodology.md#known-limitations). The next improvement is NLCD zonal statistics for habitat condition and land-cover change, keeping raw class percentages visible so users can see why a cell received its score.

## Deployment

The `dist/` folder is a static site. To publish it with GitHub Pages: **Settings → Pages → Build and deployment → Source: GitHub Actions**. The workflow in `.github/workflows/pages.yml` then deploys `dist/` on every push to `main`. If your organization restricts Pages, any static host works.

## Data sources

GBIF (species), U.S. Census TIGER/Line (boundary), USGS Annual NLCD (land cover), USGS PAD-US (protected areas), OpenStreetMap (roads). See [docs/data-sources.md](docs/data-sources.md) and review each source's license and citation guidance before presenting results.

## Team

Chengyue Ji, Ling Song, Zidong Zhang, Ruhong Sheng, and Yunqi Cui. See [docs/product-description.md](docs/product-description.md).
