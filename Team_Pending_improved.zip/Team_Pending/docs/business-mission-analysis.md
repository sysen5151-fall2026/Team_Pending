# Business and mission analysis

> **TODO (team):** this file was empty in the original repository. The headings
> below are a starting structure; replace the prompts with the team's own analysis.

## Mission statement
<!-- One or two sentences: who the product serves and the outcome it creates. -->

## Stakeholders and users
<!-- Planners, conservation organizations, land managers, researchers: what does each need? -->

## Problem and current alternatives
<!-- How do these users identify at-risk areas today, and where does that fall short? -->

## Value proposition
<!-- Why is a transparent, screening-level risk score useful? -->

## Success measures
<!-- How will the team know the product works? (e.g. user tasks completed, agreement with expert review) -->

## Constraints and risks
<!-- Data quality, calibration, appropriate use. See methodology.md for known technical limitations. -->

## Open questions
<!-- Anything the team still needs to decide or learn. -->
