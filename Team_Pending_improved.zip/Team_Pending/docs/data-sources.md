# Data sources

| Layer | Source | How it is obtained |
|---|---|---|
| Species observations | GBIF Occurrence API | `scripts/download_gbif.py` (up to 5,000 records) |
| County boundary | U.S. Census TIGER/Line | `scripts/download_boundary.py` |
| Land cover | USGS Annual NLCD | Manual GeoTIFF download to `data/raw/land_cover.tif` (not yet used by the scoring) |
| Protected areas | USGS PAD-US | Manual state download, clipped to Tompkins County, saved as `data/raw/protected_areas.geojson` |
| Roads | OpenStreetMap | Saved as `data/raw/roads.geojson` |

Raw and processed data are git-ignored (`data/raw/`, `data/processed/`); only the demo file `dist/data/risk_grid.geojson` is committed.

Before presenting results, review each source's license, citation guidance, coordinate quality, temporal coverage, and sampling limitations. GBIF records in particular reflect observer effort as well as true species presence.
