"""InVEST-style Habitat Quality scoring.

This module is the single source of truth for the model parameters and
equations. It is imported by the data pipeline (scripts/build_risk_grid.py),
the demo-data generator (scripts/make_demo_data.py) and the tests, so the
three can never drift apart.

    Q_xj    = H_j * [1 - D_xj^z / (D_xj^z + k^z)]
    Risk_xj = 1 - Q_xj

Source: Natural Capital Project, InVEST Habitat Quality user guide.
All weights, sensitivities and k are PROTOTYPE values that need literature or
expert calibration before any decision use.
"""
import numpy as np
import pandas as pd

# --- Model parameters -------------------------------------------------------
Z = 2.5  # fixed by InVEST
K = 0.5  # half-saturation constant; prototype value because degradation is normalized

THREAT_WEIGHTS = {"road": 0.4, "urban": 0.4, "agriculture": 0.2}

HABITAT_SUITABILITY = {
    "Forest": 1.0,
    "Wetland": 1.0,
    "Agriculture": 0.35,
    "Mixed habitat": 0.7,
}

HABITAT_SENSITIVITY = {
    "Forest": {"road": 0.7, "urban": 0.9, "agriculture": 0.6},
    "Wetland": {"road": 0.8, "urban": 1.0, "agriculture": 0.9},
    "Agriculture": {"road": 0.3, "urban": 0.5, "agriculture": 0.1},
    "Mixed habitat": {"road": 0.6, "urban": 0.7, "agriculture": 0.5},
}

# Protection lowers accessibility to threats (InVEST "beta"): 1 = fully exposed.
PROTECTION_EFFECT = 0.7
MIN_ACCESSIBILITY = 0.3

# Risk bands used by the dashboard legend, highest first.
RISK_BANDS = ((0.75, "very-high"), (0.50, "high"), (0.25, "moderate"), (0.0, "low"))


# --- Helpers ----------------------------------------------------------------
def normalize(series):
    """Min-max scale a Series to [0, 1]; a constant series becomes all zeros."""
    series = series.fillna(0).astype(float)
    span = series.max() - series.min()
    if span:
        return (series - series.min()) / span
    return pd.Series(0, index=series.index, dtype=float)


def accessibility_from_protection(protected_fraction):
    """Convert the protected-area fraction of a cell (0-1) to accessibility."""
    return np.clip(1 - PROTECTION_EFFECT * protected_fraction, MIN_ACCESSIBILITY, 1.0)


def degradation(effects, habitat, accessibility):
    """Total threat degradation D for one cell.

    effects: dict with keys road / urban / agriculture, each in [0, 1].
    """
    sensitivity = HABITAT_SENSITIVITY[habitat]
    return accessibility * sum(
        THREAT_WEIGHTS[t] * effects[t] * sensitivity[t] for t in THREAT_WEIGHTS
    )


def habitat_quality(suitability, degradation, z=Z, k=K):
    """InVEST habitat quality Q. Works on scalars and pandas Series."""
    return suitability * (1 - (degradation**z / (degradation**z + k**z)))


def habitat_risk(suitability, degradation, z=Z, k=K):
    """Risk = 1 - Q."""
    return 1 - habitat_quality(suitability, degradation, z=z, k=k)


def risk_level(score):
    """Map a risk score to the band name used by the dashboard."""
    for lower_bound, name in RISK_BANDS:
        if score >= lower_bound:
            return name
    return RISK_BANDS[-1][1]
