"""Shared scoring logic for the Biodiversity Risk Map."""
