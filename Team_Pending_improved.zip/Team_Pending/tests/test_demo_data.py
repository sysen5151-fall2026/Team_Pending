"""Checks on the demo GeoJSON that the dashboard loads."""
import json
from pathlib import Path

from biodiversity_risk.scoring import habitat_quality
from scripts.make_demo_data import build_features

DATA = Path(__file__).parents[1] / "dist/data/risk_grid.geojson"
REQUIRED = {
    "cell_id", "habitat", "species_count", "habitat_suitability", "accessibility",
    "road_effect", "urban_effect", "agriculture_effect", "degradation",
    "habitat_quality", "risk_score",
}


def load():
    return json.loads(DATA.read_text())


def test_collection_shape():
    data = load()
    assert data["type"] == "FeatureCollection"
    assert len(data["features"]) == 36


def test_cell_ids_are_unique():
    ids = [f["properties"]["cell_id"] for f in load()["features"]]
    assert len(ids) == len(set(ids))


def test_every_feature_has_required_properties():
    for feature in load()["features"]:
        assert REQUIRED <= set(feature["properties"]), feature["properties"]["cell_id"]


def test_scores_and_effects_are_in_unit_interval():
    for feature in load()["features"]:
        p = feature["properties"]
        for key in ("risk_score", "habitat_quality", "road_effect", "urban_effect", "agriculture_effect"):
            assert 0.0 <= p[key] <= 1.0, (p["cell_id"], key)


def test_polygons_are_closed_rings():
    for feature in load()["features"]:
        ring = feature["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]
        assert len(ring) >= 4


def test_stored_quality_matches_equation():
    # Inputs are rounded to 3 decimals in the file, hence the tolerance.
    for feature in load()["features"]:
        p = feature["properties"]
        expected = habitat_quality(p["habitat_suitability"], p["degradation"])
        assert abs(expected - p["habitat_quality"]) < 0.002, p["cell_id"]


def test_risk_is_one_minus_quality():
    for feature in load()["features"]:
        p = feature["properties"]
        assert abs((1 - p["habitat_quality"]) - p["risk_score"]) < 0.002, p["cell_id"]


def test_generator_reproduces_committed_file():
    """The file in dist/data must be exactly what make_demo_data.py produces."""
    assert build_features() == load()["features"]
