"""Tests for the real scoring code in biodiversity_risk.scoring."""
import pandas as pd

from biodiversity_risk.scoring import (
    HABITAT_SENSITIVITY,
    HABITAT_SUITABILITY,
    MIN_ACCESSIBILITY,
    THREAT_WEIGHTS,
    accessibility_from_protection,
    degradation,
    habitat_quality,
    habitat_risk,
    normalize,
    risk_level,
)


def test_normalize_range():
    assert normalize(pd.Series([2, 4, 6])).tolist() == [0.0, 0.5, 1.0]


def test_constant_normalizes_to_zero():
    assert normalize(pd.Series([3, 3])).tolist() == [0.0, 0.0]


def test_normalize_treats_missing_as_zero():
    assert normalize(pd.Series([None, 5.0, 10.0])).tolist() == [0.0, 0.5, 1.0]


def test_risk_increases_with_degradation():
    assert habitat_risk(1.0, 0.8) > habitat_risk(1.0, 0.2)


def test_zero_degradation_preserves_suitable_habitat():
    assert habitat_risk(1.0, 0.0) == 0.0


def test_zero_degradation_risk_is_one_minus_suitability():
    for habitat, suitability in HABITAT_SUITABILITY.items():
        assert abs(habitat_risk(suitability, 0.0) - (1 - suitability)) < 1e-12, habitat


def test_quality_is_bounded_by_suitability():
    for d in (0.0, 0.1, 0.5, 1.0, 5.0):
        assert 0.0 <= habitat_quality(0.7, d) <= 0.7


def test_known_value():
    # Hand-computed: D=0.24, H=0.7, z=2.5, k=0.5 -> risk of about 0.396.
    assert round(habitat_risk(0.7, 0.24), 3) == 0.396


def test_half_saturation_at_k():
    # At D = k the degradation term equals exactly one half.
    assert abs(habitat_quality(1.0, 0.5) - 0.5) < 1e-12


def test_quality_works_on_series():
    result = habitat_quality(pd.Series([1.0, 1.0]), pd.Series([0.0, 0.5]))
    assert result.round(6).tolist() == [1.0, 0.5]


def test_accessibility_bounds():
    assert accessibility_from_protection(0.0) == 1.0
    assert abs(accessibility_from_protection(1.0) - MIN_ACCESSIBILITY) < 1e-12


def test_accessibility_decreases_with_protection():
    assert accessibility_from_protection(0.8) < accessibility_from_protection(0.2)


def test_degradation_scales_with_accessibility():
    effects = {"road": 0.5, "urban": 0.5, "agriculture": 0.5}
    full = degradation(effects, "Forest", 1.0)
    protected = degradation(effects, "Forest", 0.3)
    assert abs(protected - 0.3 * full) < 1e-12


def test_wetland_is_more_sensitive_to_urban_than_agriculture_land():
    effects = {"road": 0.0, "urban": 1.0, "agriculture": 0.0}
    assert degradation(effects, "Wetland", 1.0) > degradation(effects, "Agriculture", 1.0)


def test_threat_weights_sum_to_one():
    assert abs(sum(THREAT_WEIGHTS.values()) - 1.0) < 1e-12


def test_every_habitat_has_all_threat_sensitivities():
    assert set(HABITAT_SENSITIVITY) == set(HABITAT_SUITABILITY)
    for habitat, values in HABITAT_SENSITIVITY.items():
        assert set(values) == set(THREAT_WEIGHTS), habitat


def test_risk_level_boundaries():
    assert risk_level(0.75) == "very-high"
    assert risk_level(0.7499) == "high"
    assert risk_level(0.50) == "high"
    assert risk_level(0.25) == "moderate"
    assert risk_level(0.2499) == "low"
    assert risk_level(0.0) == "low"
